import pygame
import random
import sys

pygame.init()
white = (255, 255, 255)
black = (0, 0, 0)
green = (0, 255, 0)
blue = (0, 0, 128)
# set screen size to full screen
screen = pygame.display.set_mode()
screen_x, screen_y = screen.get_size()
print(screen_x, screen_y)
inner_screen_width = screen_x*0.75
inner_screen_height = screen_y*0.75
border = int(inner_screen_width/25)
rectangle = pygame.Rect(screen_x/8, screen_y/8, inner_screen_width, inner_screen_height)
screen.fill(white)

status = True
stoproll = False

# update changes to the screen
pygame.display.flip()

# make a rectangle
pygame.draw.rect(screen, black, rectangle, border)
pygame.display.flip()

# every image 1/3 of the screen
DEFAULT_IMAGE_SIZE = ((inner_screen_width/3-border*2),inner_screen_height - border*2)

image_1 = pygame.image.load('images/17f.jpg')
image_2 = pygame.image.load('images/download.jpg')
image_3 = pygame.image.load('images/hqdefault.jpg')
image_a = pygame.image.load('images/wasser.jpg')
image_b = pygame.image.load('images/zout_2.jpg')
image_c = pygame.image.load('images/noordzeewater.jpg')

image_1 = pygame.transform.scale(image_1, DEFAULT_IMAGE_SIZE)
image_2 = pygame.transform.scale(image_2, DEFAULT_IMAGE_SIZE)
image_3 = pygame.transform.scale(image_3, DEFAULT_IMAGE_SIZE)
image_a = pygame.transform.scale(image_a, DEFAULT_IMAGE_SIZE)
image_b = pygame.transform.scale(image_b, DEFAULT_IMAGE_SIZE)
image_c = pygame.transform.scale(image_c, DEFAULT_IMAGE_SIZE)

imagelist = [image_a, image_b, image_c]

attempts = 0

def roll(attempt):


    attempt += 1
    pick_image_1 = random.choice(imagelist)
    pick_image_2 = random.choice(imagelist)
    pick_image_3 = random.choice(imagelist)
    sound_1 = pygame.mixer.Sound('images/spinning-karma-machine-169203.wav')
    sound_2 = pygame.mixer.Sound('images/error-83494.wav')

    while pick_image_2 == pick_image_1 or pick_image_2 == pick_image_3:
        pick_image_2 = random.choice(imagelist)
    #while pick_image_3 == pick_image_1 or pick_image_3 == pick_image_2:
        #pick_image_3 = random.choice(imagelist)

    screen.fill(white)
    pygame.draw.rect(screen, black, rectangle, border)
    pygame.display.flip()

    sound_1.play()
    for i in range(6):
        for i in range(0, 3):
            if (i == 0):
                screen.blit(image_a, (screen_x / 8 + border, screen_y / 8 + border))
                pygame.display.flip()
            elif (i == 1):
                screen.blit(image_b, (screen_x / 8 + border, screen_y / 8 + border))
                pygame.display.flip()
            else:
                screen.blit(image_c, (screen_x / 8 + border, screen_y / 8 + border))
                pygame.display.flip()
            pygame.time.delay(100)
    screen.blit(pick_image_1, (screen_x / 8 + border, screen_y / 8 + border))
    pygame.display.flip()

    for i in range(6):
        for i in range(0, 3):
            if (i == 0):
                screen.blit(image_a, (screen_x / 8 + border + (inner_screen_width / 3), screen_y / 8 + border))
                pygame.display.flip()
            elif (i == 1):
                screen.blit(image_b, (screen_x / 8 + border + (inner_screen_width / 3), screen_y / 8 + border))
                pygame.display.flip()
            else:
                screen.blit(image_c, (screen_x / 8 + border + (inner_screen_width / 3), screen_y / 8 + border))
                pygame.display.flip()
            pygame.time.delay(100)
    screen.blit(pick_image_2, (screen_x / 8 + border + (inner_screen_width / 3), screen_y / 8 + border))
    pygame.display.flip()

    for i in range(6):
        for i in range(0, 3):
            if (i == 0):
                screen.blit(image_a, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
                pygame.display.flip()
            elif (i == 1):
                screen.blit(image_b, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
                pygame.display.flip()
            else:
                screen.blit(image_c, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
                pygame.display.flip()
            pygame.time.delay(100)
    screen.blit(pick_image_3, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
    pygame.display.flip()

    sound_1.stop()
    sound_2.play()
    print(attempt)
    return attempt

def display(attempt):
    if attempt == 2:
        screen.blit(image_a, (screen_x / 8 + border, screen_y / 8 + border))
        pygame.display.flip()
    elif attempt == 4:
        screen.blit(image_b, (screen_x / 8 + border + (inner_screen_width / 3), screen_y / 8 + border))
        pygame.display.flip()
    elif attempt == 6:
        screen.blit(image_c, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
        pygame.display.flip()
    elif attempt == 8:
        screen.blit(image_a, (screen_x / 8 + border, screen_y / 8 + border))
        screen.blit(image_b, (screen_x / 8 + border + (inner_screen_width / 3), screen_y / 8 + border))
        screen.blit(image_c, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
        pygame.display.flip()
    elif attempt == 10:
        attempt = 0
    return attempt


running = True
while running:
    pygame.time.delay(10)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()

    key = pygame.key.get_pressed()
    if key[pygame.K_SPACE]:
        attempts = roll(attempts)
        #attempts = display(attempts)
        status = False
        if status == False:
            pass