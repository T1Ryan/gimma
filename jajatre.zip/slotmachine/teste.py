import pygame
import random
import sys

pygame.init()
white = (255, 255, 255)
black = (0, 0, 0)
green = (0, 255, 0)
blue = (0, 0, 128)
# set screen size to full screen
screen = pygame.display.set_mode()
screen_x, screen_y = screen.get_size()
print(screen_x, screen_y)
inner_screen_width = screen_x*0.75
inner_screen_height = screen_y*0.75
border = int(inner_screen_width/25)
rectangle = pygame.Rect(screen_x/8, screen_y/8, inner_screen_width, inner_screen_height)
screen.fill(white)

status = True

# update changes to the screen
pygame.display.flip()

# make a rectangle
pygame.draw.rect(screen, black, rectangle, border)
pygame.display.flip()

# every image 1/3 of the screen
DEFAULT_IMAGE_SIZE = ((inner_screen_width/3-border*2),inner_screen_height - border*2)

image_1 = pygame.image.load('images/dog.jpg')
image_2 = pygame.image.load('images/cat.jpg')
image_3 = pygame.image.load('images/owl.png')

image_1 = pygame.transform.scale(image_1, DEFAULT_IMAGE_SIZE)
image_2 = pygame.transform.scale(image_2, DEFAULT_IMAGE_SIZE)
image_3 = pygame.transform.scale(image_3, DEFAULT_IMAGE_SIZE)

imagelist = [image_1, image_2, image_3]

attempts = 0

def roll(attempt):
    attempt += 1
    pick_image_1 = random.choice(imagelist)
    pick_image_2 = random.choice(imagelist)
    pick_image_3 = random.choice(imagelist)
    sound_1 = pygame.mixer.Sound('images/spinning-karma-machine-169203.wav')
    sound_2 = pygame.mixer.Sound('images/error-83494.wav')

    while pick_image_2 == pick_image_1 or pick_image_2 == pick_image_3:
        pick_image_2 = random.choice(imagelist)
    while pick_image_3 == pick_image_1 or pick_image_3 == pick_image_2:
        pick_image_3 = random.choice(imagelist)

    sound_1.play()
    for i in range(6):
        for i in range(0, 3):
            if (i == 0):
                screen.blit(image_1, (screen_x / 8 + border, screen_y / 8 + border))
                pygame.display.flip()
            elif (i == 1):
                screen.blit(image_2, (screen_x / 8 + border, screen_y / 8 + border))
                pygame.display.flip()
            else:
                screen.blit(image_3, (screen_x / 8 + border, screen_y / 8 + border))
                pygame.display.flip()
            pygame.time.delay(100)
    screen.blit(pick_image_1, (screen_x / 8 + border, screen_y / 8 + border))
    pygame.display.flip()

    for i in range(6):
        for i in range(0, 3):
            if (i == 0):
                screen.blit(image_1, (screen_x / 8 + border + (inner_screen_width / 3), screen_y / 8 + border))
                pygame.display.flip()
            elif (i == 1):
                screen.blit(image_2, (screen_x / 8 + border + (inner_screen_width / 3), screen_y / 8 + border))
                pygame.display.flip()
            else:
                screen.blit(image_3, (screen_x / 8 + border + (inner_screen_width / 3), screen_y / 8 + border))
                pygame.display.flip()
            pygame.time.delay(100)
    screen.blit(pick_image_3, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
    pygame.display.flip()

    for i in range(6):
        for i in range(0, 3):
            if (i == 0):
                screen.blit(image_1, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
                pygame.display.flip()
            elif (i == 1):
                screen.blit(image_2, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
                pygame.display.flip()
            else:
                screen.blit(image_3, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
                pygame.display.flip()
            pygame.time.delay(100)
    screen.blit(pick_image_3, (screen_x / 8 + border + (2 * (inner_screen_width / 3)), screen_y / 8 + border))
    pygame.display.flip()

    sound_1.stop()
    sound_2.play()
    print(attempt)

    if attempt == 20 :
        print('stap 2')
        screen.fill(black)
        font = pygame.font.SysFont('couriernew', 32)
        text = font.render('Je hebt al 20 keer geprobeerd.', True, green, black)
        text2 = font.render('Ik zou stoppen. Straks krijg je nog een gokverslaving.', True, green, black)
        text3 = font.render('Code: 4321', True, green, black)
        textRect = text.get_rect()
        textRect2 = text2.get_rect()
        textRect3 = text3.get_rect()
        textRect.center = (screen_x / 2, (screen_y / 2) - 50)
        textRect2.center = (screen_x / 2, screen_y / 2)
        textRect3.center = (screen_x / 2, (screen_y / 2) + 50)
        screen.blit(text, textRect)
        screen.blit(text2, textRect2)
        screen.blit(text3, textRect3)
        pygame.display.update()
    return attempt


running = True
while running:
    pygame.time.delay(10)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()

    key = pygame.key.get_pressed()
    if key[pygame.K_SPACE]:
        attempts = roll(attempts)
        status = False
        if status == False:
            pass